package com.oracle.my.kafka;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.admin.TopicListing;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.KafkaFuture;
import org.apache.kafka.common.config.SslConfigs;


import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

public class MyKafkaAdmin {
    //k8-wrkr-1: 129.213.88.145
    //k8-wrkr-2: 129.213.149.212
    //k8-wrkr-3: 129.213.19.4
    //k8-master: 129.213.86.249

    //kafka-cluster-ip: 10.21.32.249, 10.21.234.114, 10.21.153.235, 10.21.33.121

    //private static final String KAFKA_BROKER_URLS = "http://10.21.234.114:32367"; //http://localhost:9092"; //
    // comma-separated
    //private static final String KAFKA_TOPIC_NAME = "test-topic-rahul-1";

    private static String topic = null;
    private static String brokerURLs = null;
    private static boolean createTopic = false;
    private static boolean listTopics = false;
    private static int numPartitions = 1;
    private static short replicationFactor = 1;

    private static boolean sslEnabled = false;
    private static String truststoreLoc = null;
    private static String truststorePass = null;
    private static String keystoreLoc = null;
    private static String keystorePass = null;
    private static String keyPass = null;

    public static void main(String[] args) {

        if (args == null) {
            printUsage();
        }

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-create-topic": {
                    createTopic = true;
                    break;
                }
                case "-partitions": {
                    numPartitions = Integer.parseInt(args[++i]);
                    break;
                }
                case "-replication": {
                    replicationFactor = Short.parseShort(args[++i]);
                    break;
                }
                case "-topic": {
                    topic = args[++i];
                    break;
                }
                case "-brokerURLs": {
                    brokerURLs = args[++i];
                    break;
                }
                case "-truststoreLoc": {
                    truststoreLoc = args[++i];
                    break;
                }
                case "-truststorePass": {
                    truststorePass = args[++i];
                    break;
                }
                case "-keystoreLoc": {
                    keystoreLoc = args[++i];
                    break;
                }
                case "-keystorePass": {
                    keystorePass = args[++i];
                    break;
                }
                case "-keyPass": {
                    keyPass = args[++i];
                    break;
                }
                case "-ssl": {
                    sslEnabled = true;
                    break;
                }
                default: {
                    System.out.printf("Invalid argument: %s\n", args[i]);
                    printUsage();
                }

            }
        }

        if ((topic == null) || (brokerURLs == null)) {
            printUsage();
        }

        if (createTopic) {
            if ((numPartitions < 1) || (replicationFactor < 1)) {
                printUsage();
            }
        }

        System.out.println("Using...");

        System.out.printf("\tTopic: %s\n", topic);
        System.out.printf("\tKafka Broker URLs: %s\n", brokerURLs);

        if (createTopic) {
            System.out.printf("\tPartitions: %s\n", numPartitions);
            System.out.printf("\tPartition Replication Factor: %s\n", replicationFactor);
        }

        System.out.printf("\tSSL: %b\n", sslEnabled);
        if (sslEnabled) {
            System.out.printf("\tTruststore Location: %s\n", truststoreLoc);
            System.out.printf("\tTruststore Password: %s\n", truststorePass);
            System.out.printf("\tKeystore Location: %s\n", keystoreLoc);
            System.out.printf("\tKeystore Password: %s\n", keystorePass);
            System.out.printf("\tKey Password: %s\n", keyPass);
        }

        if (createTopic) {
            createTopic();
        }
    }


    private static void printUsage() {
        System.out.println("Usage:");
        System.out.println("\tjava com.oracle.my.kafka.MyKafkaAdmin -create-topic -topic <topic-name> -brokerURLs " +
                "<broker-urls " +
                "as csv> [optional args]");
        System.out.println("where, optional args are...");
        System.out.printf("\t-partitions\n\t\tnumber of partitions to create\n");
        System.out.printf("\t-replication\n\t\tthe replication factor for each partition\n");
        System.out.printf("\t-ssl\n\t\tssl enabled\n");
        System.out.printf("\t-truststoreLoc <truststoreLoc>\n\t\tssl truststore location\n");
        System.out.printf("\t-truststorePass <truststorePass>\n\t\tssl truststore password\n");
        System.out.printf("\t-keystoreLoc <keystoreLoc>\n\t\tssl keystore location\n");
        System.out.printf("\t-keystorePass <keystorePass>\n\t\tssl keystore password\n");
        System.out.printf("\t-keyPass <keyPass>\n\t\tssl key password\n");

        System.exit(1);
    }


    private static void createTopic() {

        AdminClient adminClient = null;
        try {

            Properties props = new Properties();
            props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, brokerURLs);

            if (sslEnabled) {
                //configure the following three settings for SSL Encryption
                props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
                //props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "/var/private/ssl/kafka.client.truststore.jks");
                props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, truststoreLoc);
                props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePass);

                // configure the following three settings for SSL Authentication
                //props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, "/var/private/ssl/kafka.client.keystore.jks");
                props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, keystoreLoc);
                props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePass);
                props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, keyPass);
            }

            adminClient = AdminClient.create(props);

            NewTopic newTopic = new NewTopic(topic, numPartitions, replicationFactor);

            List<NewTopic> topicsToCreate = new ArrayList<>();
            topicsToCreate.add(newTopic);

            System.out.printf("Creating Topic : %s\n", topic);
            adminClient.createTopics(topicsToCreate);

            System.out.println("Listing Topics...");
            ListTopicsResult listTopicsResult = adminClient.listTopics();
            KafkaFuture<java.util.Collection<TopicListing>> topicCollection = listTopicsResult.listings();
            Collection<TopicListing> topics = topicCollection.get();
            for (TopicListing topic : topics) {
                System.out.printf("\tTopic: %s\n", topic.name());
            }
            System.out.println("Done");
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (adminClient != null) {
                adminClient.close();
            }
        }
    }
}

