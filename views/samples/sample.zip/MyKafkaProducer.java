package com.oracle.my.kafka;

import java.time.LocalDateTime;
import java.util.Properties;

import org.apache.kafka.common.config.SslConfigs;

//import simple producer packages
import org.apache.kafka.clients.CommonClientConfigs;

//import KafkaProducer packages
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;

public class MyKafkaProducer {

    private static String topic = null;
    private static String brokerURLs = null;

    private static boolean sslEnabled = false;
    private static String truststoreLoc = null;
    private static String truststorePass = null;
    private static String keystoreLoc = null;
    private static String keystorePass = null;
    private static String keyPass = null;

    public static void main(String[] args) throws Exception {

        if (args == null) {
            printUsage();
        }

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-topic": {
                    topic = args[++i];
                    break;
                }
                case "-brokerURLs": {
                    brokerURLs = args[++i];
                    break;
                }
                case "-truststoreLoc": {
                    truststoreLoc = args[++i];
                    break;
                }
                case "-truststorePass": {
                    truststorePass = args[++i];
                    break;
                }
                case "-keystoreLoc": {
                    keystoreLoc = args[++i];
                    break;
                }
                case "-keystorePass": {
                    keystorePass = args[++i];
                    break;
                }
                case "-keyPass": {
                    keyPass = args[++i];
                    break;
                }
                case "-ssl": {
                    sslEnabled = true;
                    break;
                }
                default: {
                    System.out.printf("Invalid argument: %s\n", args[i]);
                    printUsage();
                }

            }
        }

        if ((topic == null) || (brokerURLs == null)) {
            printUsage();
        }

        System.out.println("Using...");

        System.out.printf("\tTopic: %s\n", topic);
        System.out.printf("\tKafka Broker URLs: %s\n", brokerURLs);

        System.out.printf("\tSSL: %b\n", sslEnabled);
        if (sslEnabled) {
            System.out.printf("\tTruststore Location: %s\n", truststoreLoc);
            System.out.printf("\tTruststore Password: %s\n", truststorePass);
            System.out.printf("\tKeystore Location: %s\n", keystoreLoc);
            System.out.printf("\tKeystore Password: %s\n", keystorePass);
            System.out.printf("\tKey Password: %s\n", keyPass);
        }

        produceMessage();
    }

    private static void printUsage() {
        System.out.println("Usage:");
        System.out.println("\tjava com.oracle.my.kafka.MyKafkaProducer -topic <topic-name> -brokerURLs <broker-urls " +
                "as csv> [optional args]");
        System.out.println("where, optional args are...");
        System.out.printf("\t-ssl\n\t\tssl enabled\n");
        System.out.printf("\t-truststoreLoc <truststoreLoc>\n\t\tssl truststore location\n");
        System.out.printf("\t-truststorePass <truststorePass>\n\t\tssl truststore password\n");
        System.out.printf("\t-keystoreLoc <keystoreLoc>\n\t\tssl keystore location\n");
        System.out.printf("\t-keystorePass <keystorePass>\n\t\tssl keystore password\n");
        System.out.printf("\t-keyPass <keyPass>\n\t\tssl key password\n");

        System.exit(1);
    }

    private static void produceMessage() {
        Producer<String, String> producer = null;

        try {

            // create instance for properties to access producer configs
            Properties props = new Properties();
            props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
                    brokerURLs);
            props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                    "org.apache.kafka.common.serialization.ByteArraySerializer");
            props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                    "org.apache.kafka.common.serialization.StringSerializer");

            if (sslEnabled) {
                //configure the following three settings for SSL Encryption
                props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
                //props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "/var/private/ssl/kafka.client.truststore.jks");
                props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, truststoreLoc);
                props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePass);

                // configure the following three settings for SSL Authentication
                //props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, "/var/private/ssl/kafka.client.keystore.jks");
                props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, keystoreLoc);
                props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePass);
                props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, keyPass);
            }

            ////Set acknowledgements for producer requests.
            //props.put("acks", "all");
            //
            ////If the request fails, the producer can automatically retry,
            //props.put("retries", 0);
            //
            ////Specify buffer size in config
            //props.put("batch.size", 16384);
            //
            ////Reduce the no of requests less than 0
            //props.put("linger.ms", 1);
            //
            ////The buffer.memory controls the total amount of memory available to the producer for buffering.
            //props.put("buffer.memory", 33554432);

            //create KafkaProducer
            producer = new KafkaProducer<String, String>(props);
            LocalDateTime currentTime = LocalDateTime.now();
            ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, currentTime
                    .toString());

            System.out.printf("Publishing to Topic: %s, Message: %s\n", topic, currentTime.toString());
            producer.send(record);
            System.out.println("Message sent successfully");

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (producer != null) {
                producer.close();
            }
        }
    }
}

