# Kafka Samples
It contains samples which you can try once your service is up and running.

### Running
## Run MyKafkaAdmin, it prints the Usage. Pass requried arguments as needed.
java MyKafkaAdmin 
## Run MyKafkaProducer, it prints the Usage. Pass requried arguments as needed.
java MyKafkaProducer
## Run MyKafkaConsumer, it prints the Usage. Pass requried arguments as needed.
java MyKafkaConsumer

## Authors
* **Naman Mehta (naman.mehta@oracle.com)**
