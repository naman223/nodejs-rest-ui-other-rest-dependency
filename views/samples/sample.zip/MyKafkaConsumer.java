package com.oracle.my.kafka;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.errors.WakeupException;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;

public class MyKafkaConsumer {

    private static String group = null;
    private static String topic = null;
    private static String brokerURLs = null;

    private static boolean sslEnabled = false;
    private static String truststoreLoc = null;
    private static String truststorePass = null;
    private static String keystoreLoc = null;
    private static String keystorePass = null;
    private static String keyPass = null;

    public static void main(String[] args) throws Exception {


        if (args == null) {
            printUsage();
        }

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-group": {
                    group = args[++i];
                    break;
                }
                case "-topic": {
                    topic = args[++i];
                    break;
                }
                case "-brokerURLs": {
                    brokerURLs = args[++i];
                    break;
                }
                case "-truststoreLoc": {
                    truststoreLoc = args[++i];
                    break;
                }
                case "-truststorePass": {
                    truststorePass = args[++i];
                    break;
                }
                case "-keystoreLoc": {
                    keystoreLoc = args[++i];
                    break;
                }
                case "-keystorePass": {
                    keystorePass = args[++i];
                    break;
                }
                case "-keyPass": {
                    keyPass = args[++i];
                    break;
                }
                case "-ssl": {
                    sslEnabled = true;
                    break;
                }
                default: {
                    System.out.printf("Invalid argument: %s\n", args[i]);
                    printUsage();
                }

            }
        }

        if ((topic == null) || (group == null) || (brokerURLs == null)) {
            printUsage();
        }

        System.out.println("Using...");

        System.out.printf("\tTopic: %s\n", topic);
        System.out.printf("\tConsumer Group: %s\n", group);
        System.out.printf("\tKafka Broker URLs: %s\n", brokerURLs);

        System.out.printf("\tSSL: %b\n", sslEnabled);
        if (sslEnabled) {
            System.out.printf("\tTruststore Location: %s\n", truststoreLoc);
            System.out.printf("\tTruststore Password: %s\n", truststorePass);
            System.out.printf("\tKeystore Location: %s\n", keystoreLoc);
            System.out.printf("\tKeystore Password: %s\n", keystorePass);
            System.out.printf("\tKey Password: %s\n", keyPass);
        }

        ConsumerThread consumerThread = new ConsumerThread();
        consumerThread.start();
        consumerThread.join();
    }


    private static void printUsage() {
        System.out.println("Usage:");
        System.out.println("\tjava com.oracle.my.kafka.MyKafkaConsumer -topic <topic-name> -group <consumer-group> " +
                "-brokerURLs <broker-urls " +
                "as csv> [optional args]");
        System.out.println("where, optional args are...");
        System.out.printf("\t-ssl\n\t\tssl enabled\n");
        System.out.printf("\t-truststoreLoc <truststoreLoc>\n\t\tssl truststore location\n");
        System.out.printf("\t-truststorePass <truststorePass>\n\t\tssl truststore password\n");
        System.out.printf("\t-keystoreLoc <keystoreLoc>\n\t\tssl keystore location\n");
        System.out.printf("\t-keystorePass <keystorePass>\n\t\tssl keystore password\n");
        System.out.printf("\t-keyPass <keyPass>\n\t\tssl key password\n");

        System.exit(1);
    }

    private static class ConsumerThread extends Thread {
        private KafkaConsumer<String, String> kafkaConsumer;

        public ConsumerThread() {
            try {
                // create instance for properties to access consumer configs
                Properties props = new Properties();
                props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,
                        brokerURLs);

                props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
                        "org.apache.kafka.common.serialization.StringDeserializer");
                props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
                        "org.apache.kafka.common.serialization.StringDeserializer");

                props.put(ConsumerConfig.GROUP_ID_CONFIG, group);
                //props.put(ConsumerConfig.CLIENT_ID_CONFIG, "simple");

                if (sslEnabled) {
                    //configure the following three settings for SSL Encryption
                    props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
                    //props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "/var/private/ssl/kafka.client.truststore
                    // .jks");
                    props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, truststoreLoc);
                    props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePass);

                    // configure the following three settings for SSL Authentication
                    //props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, "/var/private/ssl/kafka.client.keystore.jks");
                    props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, keystoreLoc);
                    props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePass);
                    props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, keyPass);
                }


                kafkaConsumer = new KafkaConsumer<String, String>(props);
                //kafkaConsumer.subscribe(Arrays.asList(topic));

                kafkaConsumer.subscribe(Arrays.asList(topic), new ConsumerRebalanceListener() {

                    public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
                        System.out.printf("Topic-Partitions %s are revoked from this consumer\n", Arrays.toString
                                (partitions.toArray()));
                    }

                    public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
                        System.out.printf("Topic-Partitions %s are assigned to this consumer\n", Arrays.toString
                                (partitions.toArray()));
                        Iterator<TopicPartition> topicPartitionIterator = partitions.iterator();
                        while (topicPartitionIterator.hasNext()) {
                            TopicPartition topicPartition = topicPartitionIterator.next();
                            System.out.println("Current offset is: " + kafkaConsumer.position(topicPartition) + " " +
                                    "committed offset is: " + kafkaConsumer.committed(topicPartition));
                            System.out.println("Setting offset to: 0");
                            kafkaConsumer.seekToBeginning(Arrays.asList(topicPartition));
                            //kafkaConsumer.seek(topicPartition, 0);
                        }
                    }
                });
            } catch (Exception ex) {
                ex.printStackTrace();
                if (kafkaConsumer != null) {
                    kafkaConsumer.close();
                }
            }
        }

        public void run() {

            //Start processing messages
            try {
                boolean done = false;
                System.out.printf("Listening for messages on Topic: %s\n", topic);
                while (true) {
                    ConsumerRecords<String, String> records = kafkaConsumer.poll(100);
                    for (ConsumerRecord<String, String> record : records) {
                        System.out.printf("\tReceived Message : %s\n", record.value());
                        if ("exit".equals(record.value())) {
                            done = true;
                        }
                    }
                    if (done) break;
                }
            } catch (WakeupException ex) {
                System.out.println("Exception caught " + ex.getMessage());
                ex.printStackTrace();
            } finally {
                kafkaConsumer.close();
                System.out.println("Closed Kafka Consumer");
            }
        }

        public KafkaConsumer<String, String> getKafkaConsumer() {
            return this.kafkaConsumer;
        }
    }
}

